# Pitwall

> The infinitely configurable F1 race intelligence platform — in your pocket.

Pitwall is an open-source fan dashboard built on the [OpenF1 API](https://openf1.org). It brings real-time telemetry, inferred strategy metrics, ambient environment control, and a community layout system to anyone watching Formula 1.

![Pitwall cover](docs/pitwall_full.png)

---

## What it does

- **32 drag-and-drop widgets** — lap deltas, tyre intelligence, ERS micro-sectors, live position map, pit stop analyzer, radio scanner, championship calculator, weather radar, car visualization, and more
- **Ambient race layer** — the app (and your smart lights) respond to flag state, lead changes, fastest laps, and safety car periods
- **Multi-window workspace system** — run multiple canvases across monitors; same-workspace windows sync live
- **Driver focus system** — target any widget at a specific driver, a live race position (P1/P2/P3), or let it inherit from the canvas focus
- **Community layout sharing** — export any canvas as a compact code string and paste it anywhere (no account required)
- **Formula builder** — every inferred metric uses a user-editable formula; the community improves them over time
- **Advanced radio scanner** — squelch, key-up SFX, auto-transcription, keyword alerts, four listening modes

---

## Data source

All race data comes from the [OpenF1 API](https://openf1.org).

| Tier | Cost | What you get |
|------|------|--------------|
| Historical | Free | 2023+ data, all 32 widgets, no live updates |
| Live | $10/month (your own key) | ~3s real-time data, WebSocket feed, all 18 endpoints |

**You must provide your own OpenF1 API key for live data.** Pitwall stores it locally — it never touches our servers. Get a key at [openf1.org/subscribe](https://openf1.org/subscribe).

---

## Quick start

```bash
# Clone
git clone https://github.com/yourname/pitwall.git
cd pitwall

# Install
npm install

# Run dev server
npm run dev
```

Open `http://localhost:5173`. On first launch, you'll be prompted to enter your OpenF1 API key (optional — historical mode works without one).

---

## Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React + TypeScript + Vite |
| Layout engine | react-grid-layout |
| Charts | Recharts + D3 |
| State | Zustand + localStorage |
| Cross-window sync | BroadcastChannel API |
| Data fetching | React Query |
| API | OpenF1 REST + WebSocket |
| Audio | Web Audio API (squelch, key-up SFX) |
| Transcription | Whisper (self-hosted or cloud) |
| RGB lights | Local Node bridge → MQTT / WLED / Philips Hue / Govee |
| Weather | Windy embed (free tier) |
| Styling | Tailwind CSS |

---

## Project structure

```
pitwall/
├── src/
│   ├── app/              # App shell, workspace manager, window sync
│   ├── widgets/          # All 32 widget components
│   │   ├── LapDeltaTower/
│   │   ├── CarVisualization/
│   │   ├── TyreIntelligence/
│   │   ├── RadioScanner/
│   │   ├── WeatherRadar/
│   │   └── ...
│   ├── ambient/          # Ambient bar, flag state machine, RGB bridge
│   ├── drivers/          # Driver registry, team colors, season assets
│   ├── inference/        # Formula engine, ERS/tyre/traffic models
│   ├── api/              # OpenF1 client, WebSocket, caching
│   ├── errors/           # Error state machine, logging, diagnostics
│   └── radio/            # Scanner, squelch, transcription, SFX
├── bridge/               # Local Node RGB bridge server
│   ├── index.js
│   ├── adapters/
│   │   ├── wled.js
│   │   ├── hue.js
│   │   ├── govee.js
│   │   └── mqtt.js
├── assets/
│   ├── circuits/         # Circuit coordinates + SVG track outlines
│   ├── teams/            # Team color definitions per season
│   └── car/              # 2026-regulation car SVG base
├── docs/                 # Design documents and screenshots
└── README.md
```

---

## Widgets

### Timing & Gaps
`LapDeltaTower` · `LapTimeCard` · `GapEvolutionChart` · `StintPaceComparison` · `HeadToHeadDelta` · `SectorMiniCards`

### Telemetry
`SpeedGauge` · `ThrottleBrakeTrace` · `GearTrace` · `ThrottleHeatmap` · `ERSMicroSectors` · `DRSEfficiency` · `EngineModeTracker`

### Tyres & Strategy
`TyreIntelligence` · `StrategyTimeline` · `DegRateGraph` · `PitWindowUrgency` · `PitStopLog` · `UndercutSimulator`

### Map & Position
`FullTrackMap` · `SectorMap` · `RunningOrderStrip` · `OvertakeReplay`

### Weather & Conditions
`WeatherDashboard` · `TrackTempEvolution` · `WindDirection` · `WeatherRadar`

### Audio & Comms
`RadioScanner` · `RadioFeedText` · `RaceControlFeed`

### Championship
`StandingsTable` · `ChampionshipCalculator` · `PointsDeltaTracker`

### Visual
`CarVisualization` — 2026 SVG profile, team colors, tyre data on tires, ERS/battery bars, damage indicators

---

## Driver context system

Every widget targets data one of three ways:

```
FOCUS   → inherits canvas focus driver (default for new widgets)
ROLE    → P1 / P2 / P3 / GAP+1 / GAP-1 — follows live race position
PINNED  → locked to a specific driver by name
```

Right-click any widget → Settings → Driver to configure. P1 widgets auto-switch when the lead changes — no manual intervention needed.

---

## Layout sharing

Export any canvas as a human-readable code string:

```
pw:v1 · ws:"Race day" · focus:VER
widgets:[lap_delta·2x1, ers·1x1, tyre·1x1@NOR, traffic·1x1, battery·1x1, weather·1x1]
ambient:on · leader_color:on · rgb:wled · radio:scanner
```

Paste this into any Pitwall installation to restore the exact layout — widget positions, driver contexts, formula overrides, ambient settings, radio config. No account needed on either end.

---

## RGB light sync

A local Node bridge (`/bridge`) runs on your LAN, receives color commands from Pitwall via WebSocket, and translates to device protocols:

| Protocol | Status |
|----------|--------|
| WLED (UDP) | ✅ Supported |
| Philips Hue LAN | ✅ Supported |
| Govee LAN API | ✅ Supported |
| LIFX LAN | 🔄 Planned |
| MQTT (→ Home Assistant) | ✅ Supported |

Flag color map: green `rgb(0,200,80)` · yellow `rgb(255,214,0)` · red `rgb(255,30,30)` · SC `rgb(255,165,0)` · fastest lap `rgb(155,89,245)` · leader team color (dynamic).

---

## Error handling

The app handles six failure modes gracefully:

| State | Code | Behavior |
|-------|------|----------|
| OpenF1 unreachable | `ERR_OPENF1_UNREACHABLE` | Auto-retry every 15s, show cached data |
| No network | `ERR_OFFLINE` | Offline banner, historical mode |
| Pre-session | — | Countdown to next session, explore last race |
| No season data | `ERR_NO_SEASON_DATA` | Season picker, 2023+ available |
| App update required | — | Archive mode (full historical functionality) |
| Invalid API key | `ERR_INVALID_API_KEY` | Re-enter key, fall back to historical |

Diagnostic logs are available at Settings → Diagnostics. Optional Sentry integration for crash reporting (opt-in, no personal data).

---

## F1TV overlay (Phase 4 — not yet built)

Pitwall can run as a transparent overlay on top of F1TV using Electron's `alwaysOnTop + transparent` window mode. The app never captures or restreams content — it draws on top at the OS compositor level. See `docs/f1tv_overlay.md` for architecture details.

---

## Contributing

PRs welcome. Key contribution areas:

- **Formula improvements** — better tyre cliff models, ERS detection, traffic loss
- **Widget additions** — any widget in the catalog not yet implemented
- **RGB adapters** — new light system integrations in `/bridge/adapters`
- **Circuit data** — track coordinates and SVG outlines for new circuits
- **Transcription** — Whisper integration improvements

Please open an issue before starting large features.

---

## License

MIT — see [LICENSE](LICENSE).

OpenF1 data is used under OpenF1's terms of service. Pitwall is an independent fan project not affiliated with Formula 1, FIA, or Formula One Management. F1, FORMULA ONE, FORMULA 1, FIA FORMULA ONE WORLD CHAMPIONSHIP, GRAND PRIX and related marks are trade marks of Formula One Licensing B.V.

---

## Documentation

Full product design documents are in `/docs`:

- `pitwall_master.html` — complete consolidated product spec (all volumes)
- `pitwall_spec.md` — markdown version with screenshots
- `pitwall_design_doc.html` — v0.1 design document
- `pitwall_feature_spec.html` — v0.2 feature specification
- `pitwall_vol3_architecture_widgets.html` — v0.3 architecture & widget catalog
- `pitwall_car_widget.html` — car visualization widget (interactive)
